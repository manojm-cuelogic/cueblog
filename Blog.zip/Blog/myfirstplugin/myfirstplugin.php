<?php

/*
Plugin Name: My First Plugin
Plugin URI:http://www.exampel.com
Description:A first plugin alternative to the boring "Hello World" examples
Author: Manoj
Version:1.0
Author URI:http://www.exampel.com
*/
add_action('admin_menu','myfirstplugin_admin_actions');
function myfirstplugin_admin_actions()
{
  add_options_page('MyFirstPlugin','MyFirstPlugin','manage_options',_FILE_,'myfirstplugin_admin');
}

function myfirstplugin_admin()
{ 
?>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="http://www.cuelogic.com/blog/wp-content/themes/cueBlog/css/custom.css">
    
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" rel="stylesheet">

<link href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo get_template_directory_uri(); ?>/css/override.css" rel="stylesheet">
 

  <script>
    $(document).ready(function(){
      /*
      $(".toggle-section span").click(function(){
        $(".toggle-section span").removeClass('active');
        $(this).addClass('active');
      });

      $(".topic-toggle").on('click',function(){
        $('.topic-toggle span').toggleClass('glyphicon-chevron-down')
      });
      */
        $('#latest').click( function() {
 
         $("#sort_param").val("LATEST");
          $('form#sort_form').submit();
        }); 

        $('#trending').click( function() {
         
         $("#sort_param").val("TRENDING");
           $('form#sort_form').submit();
        }); 
    });
  </script>
<style>
.load-more {
  color: #005e9c;
  text-transform: uppercase;
  font-size: 14px;
  font-weight: bold;
}

  .filter-panel{
    padding:0;
    margin-bottom: 20px;
  }
  .sort,.dropdown-section{
    padding: 8px;
    font-weight: 500;
    font-size: 20px;
    color: #999;
  }
  .dropdown-section{
    padding: 0;
    margin-right: 20px;
  }
  .dropdown-section p{
    margin-top: 0;
    color: #fff;
    font-size: 17px;
  }
  .search-section{
    padding: 0;
  }
  .toggle-section{
    border:1px solid #bbb;
    padding: 0;
    color: #999;
  }
  .toggle-section span{
    padding: 10px 0;
    text-align: center;
    cursor: pointer;
    font-weight: 500;
  }
  .toggle-section span.active{
    background-color: #005e9c;
    color:#fff;
  }
  #topic-option{
    position: absolute;
    min-width: 970px;
    z-index: 2;
    padding: 20px 0;
    color: #005e9c;
    background-color: #fff;
    box-shadow: 0px 3px 8px -2px rgba(0,0,0,0.77);
    -webkit-box-shadow: 0px 3px 8px -2px rgba(0,0,0,0.77);
    -moz-box-shadow: 0px 3px 8px -2px rgba(0,0,0,0.77);

  }
  #topic-option li span{
    color: #005e9c;
  }
  #topic-option li span:first-child{
    float: left;
  }
  #topic-option li span:last-child{
    float: right;
  }
  #topic-option li{
    display: inline-block;
    width: 32%;
    padding: 0 20px 0px 40px;
    font-size: 16px;
  }

  .topic-toggle{
    background-color: #005e9c;
    color: #fff;
    padding: 10px;
    margin: 0;
    cursor: pointer;
  }
  .topic-toggle span{
    color: #fff;
    margin: 3px 10px;
    float: right;
  }
  .topic-toggle.active{
    background-color: #fff;
  }
  .search-section input{
    border-radius: 0;
    padding:8px 4px;
    font-size: 20px;
  }
  .search-section .glyphicon-search{
    color: #005e9c;
  }
  .search-section .form-control-feedback{
    top:5px;
  }

</style>

<?php
               $cat_args=array(
  'orderby' => 'name',
  'order' => 'ASC'
   );
$categories=get_categories($cat_args);

// Get the ID of a given category
   

    // Get the URL of this category
    
?>
        <div class="row">
          <div class="col-md-12 col-sm-12">
            <div class="col-md-8 col-sm-8 filter-panel">
              <div class="col-md-3 col-sm-4 dropdown-section pull-left">    
                <p class="topic-toggle" data-toggle="collapse" data-target="#topic-option">Select Topic <span class="glyphicon glyphicon-chevron-up"></span></p>
                  <div id="topic-option" class="collapse">
                    <ul>
                    <?php
                       foreach($categories as $category) { 
			 $category_id = get_cat_ID( $category->name );
			$category_link = get_category_link( $category_id );
                    ?>
                      <li>
                        <span><a href="<?php echo esc_url( $category_link ); ?>"><?php echo $category->name; ?></a></span>
                        <span><?php echo $category->count; ?></span>
                      </li>
                      <?php
                    }
                      ?>
                    </ul>
                  </div>
              </div>
              <span class="pull-left sort">Sort by:</span>
              <span class="col-md-4 col-sm-5 toggle-section">
                <span id="latest" class="col-md-6 col-sm-6 active">Latest</span>
                <span id="trending" class="col-md-6 col-sm-6">Trending</span>
              </span>
            </div>

            <div class="col-md-2 col-sm-3 pull-right search-section">
              <div class="has-feedback">
              <form role="search" method="get" id="searchform"
    class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <div>
        
        <input type="text" value="<?php echo get_search_query(); ?>" name="s" id="s" />
        <span class="glyphicon glyphicon-search form-control-feedback"></span>
    </div>
</form>
                  
                  
                </div>
            </div>
          </div>
        </div>
        <form id="sort_form" name="sort_form" method="GET">
          <input type="hidden" id="sort_param" name="sort_param">
        </form>


<?php 
} 
?>

<?php
/*
 * Name: index.php
 * Author:Manoj Mahamunkar
 * Created on:04 Oct 2016
 * Purpose:CUSTOM Index Funtionality
 */
?>

<?php get_header(); ?>




	<?php $count = 0; ?>
	<?php
	$sort_param = $_GET["sort_param"];
	
	if($sort_param == "TRENDING")
	{
			
			$args = array( 'numberposts' => 12,'orderby' => 'meta_value_num',
			'order' => 'DESC', 'meta_key'=>'post_views_count');
		
			echo"<script>
          $('#latest').removeClass('active');
          $('#trending').addClass('active');
      </script>";

	}	
	elseif($sort_param == "LATEST")
	{
			
		 $args = array( 'numberposts' => 12,'orderby' => 'date',
		'order' => 'DESC', );
		  echo"<script>
          $('#trending').removeClass('active');
          $('#latest').addClass('active');
      </script>";
	}
	else
	{
		 $args = array( 'numberposts' => 12,'orderby' => 'date',
		'order' => 'DESC', );
		

	}
	//$query = new WP_Query(array('posts_per_page'   => 13));
	//while ($query->have_posts()): $query->the_post(); 



function ShortenText($text) { // Function name ShortenText
  $chars_limit =25; // Character length
  $chars_text = strlen($text);
  $text = $text." ";
  $text = substr($text,0,$chars_limit);
  $text = substr($text,0,strrpos($text,' '));
 
  if ($chars_text > $chars_limit)
     { $text = $text."..."; } // Ellipsis
     return $text;
}

	$postsdetails = get_posts( $args );
	//print_r($postsdetails);
	foreach($postsdetails as $post) : setup_postdata($post);
	
	?>
	

	<?php $count++;?>
					 <?php if ($count == 1) : ?>	

	<div id="maincontent" class="post-container">				 	
				    <div class=" col-md-12 post-cont-type_1">
						<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
						<p><?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
			<?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?>
						<span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
					</div>

					<div class="row">
					<?php elseif ($count == 2) : ?>	
						<div class=" col-md-4 margin-section">
							<div class="post-cont-type_2" style="height:500px;overflow:hidden;">
								<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
								<p><?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
							</div>
						</div>
						 <?php elseif ($count == 3) : ?>	
						<div class=" col-md-4 margin-section">
							<div class="post-cont-type_3" style="height:500px;overflow:hidden;">
								<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
								<p><?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
							</div>
						</div>
						
						<div class=" col-md-4 margin-section">
							<div class="post-cont-type_4">
								<h1>TAGS</h1>
								<p><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
								</p>
							</div>
						</div>
					</div>
	  
					<div class="row mrgn-top-20">
						 <?php elseif ($count == 4) : ?>
						<div class=" col-md-8">
							<div class="post-cont-type_5" style="height:300px;overflow:hidden;">
								<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
								<p>
									<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
							</div>
							<div class="row">
							 <?php elseif ($count == 5) : ?>
									<div class=" col-md-6">
									<div class="post-cont-type_6" style="height:550px;">
										<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
										<p>
										<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
									</div>
								</div>
								 <?php elseif ($count == 6) : ?>
								<div class=" col-md-6">
								<div class="post-cont-type_6" style="height:550px;">
									<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
									<p>
									<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
								</div>
							</div>
						</div>
							</div>	

						<!-- fb widget -->
						<div class="col-md-4">
							<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FCuelogic-Technologies-298280838251%2F&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
						</div>
					</div>

				<div class="row">
					<div class=" col-md-4">
					 <?php elseif ($count == 7) : ?>
									<div class="post-cont-type_6"  style="height:550px;">
										<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
										<p>
										<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
									</div>
					</div>
					<div class=" col-md-4">
					 <?php elseif ($count == 8) : ?>
								<div class="post-cont-type_6"  style="height:550px;">
									<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
									<p>
									<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
								</div>
				</div>
				<div class=" col-md-4">
			<?php elseif ($count == 9) : ?>
									<div class="post-cont-type_6"  style="height:550px;">
										<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
										<p>
										<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
									</div>
					</div>
					<div class=" col-md-4">
				<?php elseif ($count == 10) : ?>
								<div class="post-cont-type_6"  style="height:550px;overflow:hidden;" >
									<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1><p>
									<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>			</div>
				</div>
				<div class=" col-md-4">
			<?php elseif ($count == 11) : ?>
								<div class="post-cont-type_6"  style="height:550px;overflow:hidden;" >
									<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
									<p>
										<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
								</div>
				</div>
				<div class=" col-md-4">
			<?php elseif ($count == 12) : ?>
								<div class="post-cont-type_6"  style="height:550px;overflow:hidden;" >
									<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
									<p>
										<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
								</div>
				</div>
				</div>
<?php endif; ?>				
<?php endforeach; ?>
				

		</div>
		<!-- container closed -->
		<div id="the_div_containing_li">
			
		</div>
		<div class="row mrgn-top-20">
					<div class="col-md-12 text-center">
						<a href="#" id="load_more_post" class="load-more">Load More</a>
					</div>
				</div>
	</div>
	<!-- page container closed -->

		

    <script type="text/javascript">
        /*
        jQuery(window).load(function() {
        
      // MASSONRY Without jquery
      var container = document.querySelector('#ms-container');
      var msnry = new Masonry( container, {
        itemSelector: '.',
        columnWidth: '.',                
      });  
      
        });

      */
    </script>
    <style type="text/css">
    	/* Makes two columns 
. {
width: 50%;
}
*/
/* Makes three columns 
. {
width: 33%;
}
*/
    </style>
<?php 
	
get_footer(); ?>
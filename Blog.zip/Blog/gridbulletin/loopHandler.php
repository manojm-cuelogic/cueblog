<?php
/*
 * The template for homepage.
 */
// our loop
// Our include
define('WP_USE_THEMES', false);
require_once('../../../wp-load.php');


$page = (isset($_GET['pageNumber_val'])) ? $_GET['pageNumber_val'] : 0;

$page_sort_type =$_GET['page_sort_type'];

	if($page_sort_type == "trends")
	{
			
			$args = array( 'numberposts' => 6,'orderby' => 'meta_value_num',
			'order' => 'DESC', 'meta_key'=>'post_views_count', 'paged' => $page, 'post_status' => 'publish');
	}	
	elseif($page_sort_type == "latest")
	{
			
		 $args = array( 'numberposts' => 6,'orderby' => 'date',
		'order' => 'DESC', 'paged' => $page, 'post_status' => 'publish');
	}
	else
	{
		 $args = array( 'numberposts' => 6,'orderby' => 'date',
		'order' => 'DESC', 'paged' => $page, 'post_status' => 'publish'	);

	}
/*
$args = array( 'numberposts' => 6,'orderby' => 'date',
		'order' => 'DESC', 'paged' => $page);
	*/	

		function ShortenText($text) { // Function name ShortenText
  $chars_limit =25; // Character length
  $chars_text = strlen($text);
  $text = $text." ";
  $text = substr($text,0,$chars_limit);
  $text = substr($text,0,strrpos($text,' '));
 
  if ($chars_text > $chars_limit)
     { $text = $text."..."; } // Ellipsis
     return $text;
}
$pageposts = get_posts( $args );


 if ($pageposts): ?>
 <?php global $post; ?>
 <?php foreach ($pageposts as $post): ?>
 <?php setup_postdata($post); ?>
 
 	<div class="col-md-4">
			<?php //if ($count == 14) : ?>
			<div class="post-cont-type_6" style="height:500px;overflow:hidden;">
									<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
										<p style="color: #222222;margin-top: 5px;font-size: 14px;">
									<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
										<?php
			$author_name = get_the_author_meta('display_name',$posts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$posts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
			</div>
	</div>
 <?php endforeach; ?>
 <?php else : ?>
    <p class="center">No more post.</p>
 <?php endif; ?>

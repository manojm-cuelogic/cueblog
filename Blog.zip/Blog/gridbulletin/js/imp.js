/*
 * Name:function.js
 * Author:Manoj Mahamunkar
 * Created on:06 Oct 2016
 * Puspose: to fetch load more post in theme
 */

jQuery(document).ready(function() { 

	var URL_pram = 	getUrlVars();
	var call_to_load_param;

	function getUrlVars()
	{
    var url = window.location.href;
    var hashes =  url.substring(url.indexOf('?')+1);
    return hashes;
	}

	if((URL_pram=="sort_param=TRENDING")||(URL_pram=="sort_param=TRENDING#"))
	{
		call_to_load_param="trends";
		//alert("TRENDING");
	}	
	else if((URL_pram=="sort_param=LATEST")||(URL_pram=="sort_param=LATEST#"))
	{
		call_to_load_param="latest";
		//alert("LATEST");
	}	
	else
	{
		call_to_load_param="latest";
		//alert("LATEST");
	}
 	jQuery('#load_more_post').click(function(){
      //alert(call_to_load_param); 
      jQuery.ajax({
	type: 'POST',
	url: '/wp-admin/admin-ajax.php',
	data: {
		action: 'get_latest', // the PHP function to run
	},
	success: function(data, textStatus, XMLHttpRequest) {
		jQuery('#latest-news').html(''); // empty an element
		jQuery('#latest-news').append(data); // put our list of links into it
	},
	error: function(XMLHttpRequest, textStatus, errorThrown) {
		if(typeof console === "undefined") {
			console = {
				log: function() { },
				debug: function() { },
			};
		}
		if (XMLHttpRequest.status == 404) {
			console.log('Element not found.');
		} else {
			console.log('Error: ' + errorThrown);
		}
	}
});
   });

   	
});
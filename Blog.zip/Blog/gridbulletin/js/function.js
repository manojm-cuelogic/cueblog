/*
 * Name:function.js
 * Author:Manoj Mahamunkar
 * Created on:06 Oct 2016
 * Puspose: to fetch load more post in theme
 */

jQuery(document).ready(function() { 
	var BLOG_basedir = '/blog/';
    var URL_pram = 	getUrlVars();

	var call_to_load_param;
    var pageNumber = 1;

	function getUrlVars()
	{
        var url = window.location.href;
        var hashes =  url.substring(url.indexOf('?')+1);
        return hashes;
	}

	if((URL_pram=="sort_param=TRENDING")||(URL_pram=="sort_param=TRENDING#"))
	{
		call_to_load_param="trends";
		//alert("TRENDING");
	}	
	else if((URL_pram=="sort_param=LATEST")||(URL_pram=="sort_param=LATEST#"))
	{
		call_to_load_param="latest";
		//alert("LATEST");
	}	
	else
	{
		call_to_load_param="latest";
		//alert("LATEST");
	}
 	
    jQuery('#load_more_post').click(function(e){
 	e.preventDefault();
      //alert(call_to_load_param); 
      //console.log(window.location.host);
      //return false;
    var URL_format = 'wp-content/themes/gridbulletin/loopHandler.php';
 
    var loading = true;
    var $window = jQuery(window);
    var $content = jQuery("#the_div_containing_li");
    //var $content = $("#maincontent");
        pageNumber++;
        jQuery.ajax({
                type       : "GET",
                data       : {pageNumber_val : pageNumber,page_sort_type : call_to_load_param},
                dataType   : "html",
                url        : URL_format,
                beforeSend : function(){
                   
                },
                success    : function(data){
                //alert(pageNumber);
                    $data = jQuery(data);
                    if($data.length){
                        $data.hide();
                        $content.append($data);
                        $data.fadeIn(500, function(){
                            jQuery("#temp_load").remove();
                            loading = false;
                        });
                    } else {
                        jQuery("#temp_load").remove();
                    }
                },
                error     : function(jqXHR, textStatus, errorThrown) {
                    jQuery("#temp_load").remove();
                    alert(jqXHR + " :: " + textStatus + " :: " + errorThrown);
                }
        });
   });

   	
});



<?php
/*
 * Name:header.php
 * Author:Manoj Mahamunkar
 * Created on:04 Oct 2016
 * Purpose:The header for displaying logo, menu and header-image.
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> >

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="<?php bloginfo( 'charset' ); ?>">
<link rel="profile" href="http://gmpg.org/xfn/11">
<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php endif; ?>
<!--
	Adding Custom CSS in theme
-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!--
<link rel="stylesheet" href="<?php //bloginfo('template_url'); ?>/css/override.css" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="<?php ///bloginfo('template_url'); ?>/css/bootstrap.css">
-->
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?> >
<!-- Wrap all page content here -->
<div id="page-container">
<a class="scroll_top" href="#" style="display:none">&nbsp;</a>
<div class="container">
  <div class="navbar"> 
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
      <a title="Cuelogic" class="navbar-brand" href="http://www.cuelogic.com"><img src="<?php echo get_template_directory_uri(); ?>/images/cuelogic_logo.png" /></a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <!--<?php //wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'nav nav-pills' ) ); ?>
      <?php //get_search_form(); ?>-->
      <ul class="nav nav-pills">
      
          <li><a href="http://www.cuelogic.com/about">ABOUT</a></li>
          <li><a href="http://www.cuelogic.com/expertise">EXPERTISE</a></li>  
          <li><a href="http://www.cuelogic.com/case-studies">CASESTUDIES</a></li>         
          <li><a href="http://www.cuelogic.com/blog">BLOG</a></li>         
          <li><a href="http://www.cuelogic.com/careers">CAREERS</a></li>         
          <li><a href="http://www.cuelogic.com/contact-us">CONTACT</a></li> 
        </ul>
    </div>
  </div>
  <!-- #navbar --> 
</div>
<div class="container">
<?php myfirstplugin_admin(); ?>
<div id="maincontent">

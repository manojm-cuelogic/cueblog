<?php
/*
 * The template for displaying search results.
 */
?>

<?php get_header(); ?>
<?php
global $query_string;

$query_args = explode("&", $query_string);
$search_query = array();

	function ShortenText($text) { // Function name ShortenText
  	$chars_limit =25; // Character length
  	$chars_text = strlen($text);
  	$text = $text." ";
  	$text = substr($text,0,$chars_limit);
  	$text = substr($text,0,strrpos($text,' '));
 
  	if ($chars_text > $chars_limit)
     { $text = $text."..."; } // Ellipsis

     return $text;
}



foreach($query_args as $key => $string) {
    $query_split = explode("=", $string);
    $search_query[$query_split[0]] = urldecode($query_split[1]);
} // foreach

$search = new WP_Query($search_query);

?>
<?php if ( $search->have_posts() ) : ?>
 
            <header class="page-header">
                <span class="search-page-title"><?php printf( esc_html__( 'Search Results for: %s', stackstar ), '<span>' . get_search_query() . '</span>' ); ?></span>
            </header><!-- .page-header -->
 	 <div id="maincontent">
    <?php /* Start the Loop */ ?>
    <?php while ( $search->have_posts() ) : $search->the_post(); ?>
        <?php $count++; ?>
          	<?php if ($count == 1) : ?>
            	
             	<div class="col-md-12 post-cont-type_1">
             		<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
						
						<p style="color: #222222;margin-top: 15px;font-size: 18px;"><?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
						<span class="">by&nbsp;<a href="<?php the_author_link();?>"><?php the_author(); ?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
	
						
				</div>
			<div class="row">
					<?php elseif ($count == 2) : ?>	
						<div class="col-md-4 margin-section">
							<div class="post-cont-type_2" style="height:400px;overflow:hidden;" >
								<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
								<p style="color: #222222;margin-top: 15px;font-size: 18px;"><?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p><span class="">by&nbsp;<a href="<?php the_author_link();?>"><?php the_author(); ?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
							</div>
						</div>

			 <?php elseif ($count == 3) : ?>
			 	 <div class="col-md-4 margin-section">
						<div class="post-cont-type_3" style="height:400px;overflow:hidden;" >
						<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
						<p style="color: #222222;margin-top: 15px;font-size: 18px;"><?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
						<span class="">by&nbsp;<a href="<?php the_author_link();?>"><?php the_author(); ?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
						</div>
				</div>
			</div>

				 <?php elseif ($count == 4) : ?>
				<div class="col-md-4">
					<div class="post-cont-type_6" style="height:500px;overflow:hidden;" >
						<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
											<p style="color: #222222;margin-top: 15px;font-size: 18px;">
											<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
						<span class="">by&nbsp;<a href="<?php the_author_link();?>"><?php the_author(); ?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>					
					</div>
				</div>
				 <?php elseif ($count == 5) : ?>
				<div class="col-md-4">
					<div class="post-cont-type_6" style="height:500px;overflow:hidden;" >
						<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
											<p style="color: #222222;margin-top: 15px;font-size: 18px;">
											<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
						<span class="">by&nbsp;<a href="<?php the_author_link();?>"><?php the_author(); ?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>					
					</div>
				</div>
				 <?php elseif ($count == 6) : ?>
				<div class="col-md-4">
					<div class="post-cont-type_6" style="height:500px;overflow:hidden;" >
						<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
											<p style="color: #222222;margin-top: 15px;font-size: 18px;">
											<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
						<span class="">by&nbsp;<a href="<?php the_author_link();?>"><?php the_author(); ?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>					
					</div>
				</div>
				 <?php elseif ($count == 7) : ?>
				<div class="col-md-4">
					<div class="post-cont-type_6" style="height:500px;overflow:hidden;" >
						<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
											<p style="color: #222222;margin-top: 15px;font-size: 18px;">
											<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
						<span class="">by&nbsp;<a href="<?php the_author_link();?>"><?php the_author(); ?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>					
					</div>
				</div>
				 <?php elseif ($count == 8) : ?>
				<div class="col-md-4">
					<div class="post-cont-type_6" style="height:500px;overflow:hidden;" >
						<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
											<p style="color: #222222;margin-top: 15px;font-size: 18px;">
											<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
						<span class="">by&nbsp;<a href="<?php the_author_link();?>"><?php the_author(); ?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>					
					</div>
				</div>
				 <?php elseif ($count == 9) : ?>
				<div class="col-md-4">
					<div class="post-cont-type_6" style="height:500px;overflow:hidden;">
						<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
											<p style="color: #222222;margin-top: 15px;font-size: 18px;">
											<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
						<span class="">by&nbsp;<a href="<?php the_author_link();?>"><?php the_author(); ?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>					
					</div>
				</div>
				 <?php elseif ($count == 10) : ?>
				<div class="col-md-4">
					<div class="post-cont-type_6" style="height:500px;overflow:hidden;">
						<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
											<p style="color: #222222;margin-top: 15px;font-size: 18px;">
											<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
						<span class="">by&nbsp;<a href="<?php the_author_link();?>"><?php the_author(); ?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>					
					</div>
				</div>
				 <?php elseif ($count < 10) : ?>
				<div class="col-md-4">
					<div class="post-cont-type_6" style="height:500px;overflow:hidden;">
						<h1><a href="<?php the_permalink(); ?>"><?php echo ShortenText(get_the_title()); ?></a></h1>
											<p style="color: #222222;margin-top: 15px;font-size: 18px;">
											<?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
						<span class="">by&nbsp;<a href="<?php the_author_link();?>"><?php the_author(); ?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>					
					</div>
				</div>
				 
				
			

			<?php endif; ?>		
            <?php endwhile; ?>

 </div>

            <?php //the_posts_navigation(); ?>
 
        <?php else : ?>
 
            <?php echo "NO POST for these search"; ?>
 
        <?php endif; ?>

<?php //get_sidebar(); ?>
 <div id="last_div" style="margin-bottom:10px;"></div>
<?php get_footer(); ?>

<?php
/*
 * The template for displaying search results.
 */
?>

<?php get_header(); ?>
<div id="content">
	<?php if ( have_posts() ) : ?>

		<h1 class="page-title"><?php printf( __( 'Search Results for: %s', 'gridbulletin' ), get_search_query() ); ?>
			
		</h1>
			
		<?php //while ( have_posts() ) : the_post(); 
		$postsdetails = get_posts();
		foreach($postsdetails as $post) : setup_postdata($post); 
		?>
			<?php $count++; ?>
			<?php //get_template_part( 'content-list' ); ?>
			 <?php if ($count == 1) : ?>	

					 	
				    <div class="col-md-12 post-cont-type_1">
						<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
						<p><?php echo wp_trim_words( get_the_content(), 40, '....' ); ?></p>
			<?php
			$author_name = get_the_author_meta('display_name',$lastposts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$lastposts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?>
						<span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
					</div>
					<div class="row">
					<?php elseif ($count == 2) : ?>	
						<div class="col-md-4 margin-section">
							<div class="post-cont-type_2">
								<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
								<p><?php echo wp_trim_words( get_the_content(), 15, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$lastposts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$lastposts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
							</div>
						</div>
						 <?php elseif ($count == 3) : ?>	
						<div class="col-md-4 margin-section">
							<div class="post-cont-type_3">
								<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
								<p><?php echo wp_trim_words( get_the_content(), 20, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$lastposts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$lastposts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
							</div>
						</div>
						<div class="row mrgn-top-20">
						 <?php elseif ($count == 4) : ?>
						<div class="col-md-8">
							<div class="post-cont-type_5">
								<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
								<p>
									<?php echo wp_trim_words( get_the_content(), 15, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$lastposts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$lastposts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
							</div>
							<div class="row">
							 <?php elseif ($count == 5) : ?>
									<div class="col-md-6">
									<div class="post-cont-type_6">
										<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
										<p>
										<?php echo wp_trim_words( get_the_content(), 25, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$lastposts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$lastposts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
									</div>
								</div>
								 <?php elseif ($count == 6) : ?>
								<div class="col-md-6">
								<div class="post-cont-type_6">
									<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
									<p>
									<?php echo wp_trim_words( get_the_content(), 55, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$lastposts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$lastposts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
								</div>
							</div>
						</div>
							</div>	
							<div class="row">
					<div class="col-md-4">
					 <?php elseif ($count == 7) : ?>
									<div class="post-cont-type_6">
										<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
										<p>
										<?php echo wp_trim_words( get_the_content(), 30, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$lastposts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$lastposts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
									</div>
					</div>
					<div class="col-md-4">
					 <?php elseif ($count == 8) : ?>
								<div class="post-cont-type_6">
									<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
									<p>
									<?php echo wp_trim_words( get_the_content(), 22, '....' ); ?></p><?php
			$author_name = get_the_author_meta('display_name',$lastposts[0]->post_author);		
			$author_nicename = get_the_author_meta('user_nicename',$lastposts[0]->post_author);		
			$url = home_url( '/' );
			$author_url = esc_url( $url ).'/blog/author/'.$author_nicename; 
			?><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
								</div>
				</div>
				<div class="col-md-4">
			<?php elseif ($count == 9) : ?>
									<div class="post-cont-type_6">
										<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
										<p>
										<?php echo wp_trim_words( get_the_content(), 35, '....' ); ?></p><span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
									</div>
					</div>
					<div class="col-md-4">
				<?php elseif ($count == 10) : ?>
								<div class="post-cont-type_6">
									<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
									<p>
										<?php echo wp_trim_words( get_the_content(), 15, '....' ); ?></p>
									<span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
								</div>
				</div>
				<div class="col-md-4">
			<?php elseif ($count == 11) : ?>
								<div class="post-cont-type_6">
									<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
									<p>
										<?php echo wp_trim_words( get_the_content(),37, '....' ); ?></p>
									<span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
								</div>
				</div>
				<div class="col-md-4">
			<?php elseif ($count == 12) : ?>
								<div class="post-cont-type_6">
									<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
									<p>
										<?php echo wp_trim_words( get_the_content(),45, '....' ); ?></p>
									<span class="">by&nbsp;<a href="<?php echo $author_url;?>"><?php echo $author_name;?></a>&nbsp;|&nbsp;<?php the_time('jS F Y'); ?>&nbsp;|&nbsp;<?php echo subh_get_post_view(get_the_ID()); ?></span><span class="hash-tag"><?php the_tags( '# ', ' # ', '<br />' ); ?></span>
								</div>
				</div>
				</div>
			<?php endif; ?>

		<?php endforeach; ?>
		<?php
		//endwhile; 
		?>
		<!--
		<div class="post-nav">
			<?php // next_posts_link(); ?>
			<?php // previous_posts_link(); ?>
		</div>
	-->
	<?php else: ?>
		<?php get_template_part( 'content-none' ); ?>

	<?php endif; ?>
</div>
<?php // get_sidebar(); ?>
<?php get_footer(); ?>